describe('doPythagoras(a,b)', function () {
  it('should return the correct Pythagoras result given two positive numbers', function () {
    var a = 5;
    var b = 4;
    chai.expect(Number(doPythagoras(a, b)).toFixed(2)).to.equal(Math.sqrt(a * a + b * b).toFixed(2));
  });

  it('should return "Negative numbers" in case at least one parameter is negative', function () {
    var a = -5;
    var b = 4;
    chai.expect(doPythagoras(a, b)).to.equal("Negative numbers");
  });

  it('return "Invalid input" in case at least one input parameter is not a number (and no negative number has been entered)', function () {
    var a = "test";
    var b = 4;
    chai.expect(doPythagoras(a, b)).to.equal("Invalid input");
  });

});

describe('checkURL(filename)', function () {
  //(a) The function shall return false whenever a variable that is not a string or an empty string is passed in.
  it('should return false whenever a variable that is not a string or an empty string is passed in', function () {
    chai.expect(checkURL(5)).to.equal(false);
  });

  //(b) The function shall return true if a proper URL is passed in.
  it('should return true if a proper URL is passed in', function () {
    chai.expect(checkURL("test.txt")).to.equal(true);
  });
});

describe('markAndResetInput(inputField)', function () {
  it('should not throw an exception/error when a null object or undefined is passed in.', function () {
    chai.expect(function () { markAndResetInput(null); }).to.not.throw();
    chai.expect(function () { markAndResetInput(undefined); }).to.not.throw();
  });
});

describe('loadFileAsync(url, callback)', function () {

});

describe('Loading files', function () {
  this.timeout(10000);

  it('should call the callback with the required resource if a proper URL is provided', function (done) {
    loadFileAsync("http://veff213-sudoku.herokuapp.com/test", function (result) {
      chai.expect('Backend is online.').to.equal(result);
      done();
    });
  });

  it('should call the callback with null in case the URL is invalid or the HTTP request is not successful', function (done) {
    loadFileAsync("doesNotExist.txt", function (result) {
      chai.expect(null).to.equal(result);
      done();
    });
  });

});