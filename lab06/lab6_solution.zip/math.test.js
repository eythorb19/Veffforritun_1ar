const chai = require('chai');
const sinon = require('sinon');

const math = require('./math');

describe("doDivision(a,b)", function() {
    it("should return the right division result for 4 and 2", function() {
        chai.expect(math.doDivision(4.0,2.0).toFixed(2)).to.equal((2).toFixed(2));
    });

    //Division is only defined for numbers, 
    //so a potential corner or failure case is when a string is provided
    it("should return NaN when 2 is divided by a", function() {
        chai.expect(math.doDivision(2.0,'a')).to.be.NaN;
    });

    //Division by 0 is not defined, hence the return values might differ
    it("should return Infinity when 2 is divided by 0", function() {
        chai.expect(math.doDivision(2,0)).to.equal(Infinity);
    });
});

describe("stringifyDivision(a,b)", function() {
    it("should return the correct string for two positive numbers", function() {
        let fakeDiv = sinon.fake.returns(2.0);
        sinon.replace(math,'doDivision',fakeDiv);

        chai.expect(math.stringifyDivision(4.0,2.0)).to.equal("4 divided by 2 is 2");
    });

    after(() => {
        sinon.restore();
    });
});