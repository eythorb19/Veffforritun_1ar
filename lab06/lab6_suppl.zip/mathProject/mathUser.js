var math = require('./math');

var divResult = math.doDivision(2,2.000000001);

console.log(math.doDivision(4,2));
console.log(math.stringifyDivision(4,2));