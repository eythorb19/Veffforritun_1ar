var math = require('./math');

console.log(math.doDivision(4,2));
console.log(math.stringifyDivision(4,2));